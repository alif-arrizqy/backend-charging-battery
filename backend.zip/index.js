import express from "express";
import cors from "cors";
import M_frameRoute from "./routes/M_frameRoute.js";

const app = express();
app.use(cors());
app.use(express.json());
app.use(M_frameRoute);

app.listen(5003, () => console.log("SERVER UP AND RUNNING"));
