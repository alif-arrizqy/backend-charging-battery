import express from "express";
import {
  createMframe,
  deleteMframe,
  getMframe,
  getMframeById,
  updateMframe,
} from "../controllers/M_frameController.js";

const router = express.Router();

router.get("/getMframe", getMframe);
router.get("/getMframe/:id", getMframeById);
router.post("/createMframe", createMframe);
router.patch("/updateMframe/:kd_site", updateMframe);
router.delete("/deleteMframe/:id", deleteMframe);

export default router;
