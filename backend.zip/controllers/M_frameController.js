import { where } from "sequelize";
import M_frame from "../models/M_frameModel.js";

export const getMframe = async (req, res) => {
  try {
    const response = await M_frame.findAll();
    res.status(200).json(response);
  } catch (error) {
    console.log(error.message);
  }
};

export const getMframeById = async (req, res) => {
  try {
    const response = await M_frame.findOne();
    where: {
      id: req.params.id;
    }
    res.status(200).json(response);
  } catch (error) {
    console.log(error.message);
  }
};

export const createMframe = async (req, res) => {
  try {
    await M_frame.create(req.body);
    res.status(201).json({ msg: "mframe Created" });
  } catch (error) {
    console.log(error.message);
  }
};

export const updateMframe = async (req, res) => {
  try {
    const response = await M_frame.update(req.body, {
      where: {
        kd_site: req.params.kd_site,
      },
    });

    res.status(200).json({ msg: "mframe Updated" });
  } catch (error) {
    console.log(error.message);
  }
};

export const deleteMframe = async (req, res) => {
  try {
    const response = await M_frame.destroy({
      where: {
        id: req.params.id,
      },
    });

    res.status(200).json({ msg: "mframe Deleted" });
  } catch (error) {
    console.log(error.message);
  }
};
