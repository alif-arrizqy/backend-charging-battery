import { Sequelize } from "sequelize";
import db from "../config/dataBase.js";

const { DataTypes } = Sequelize;

const M_frame = db.define(
  "M_frame",
  {
    // id: DataTypes.INTEGER,
    kd_site: DataTypes.STRING,
    sn_frme: DataTypes.STRING,
    ip_adrs: DataTypes.STRING,
  },
  {
    freezeTabaleName: true,
  }
);

export default M_frame;

(async () => {
  await db.sync();
})();
