import { Sequelize } from "sequelize";

const db = new Sequelize("offgrid_scan", "root", "", {
  host: "localhost",
  dialect: "mysql",
});

export default db;
